import { useMemo, useState, type ReactNode } from "react"
import {
  Activity,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  Camera,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  ClipboardCheck,
  Clock3,
  FileClock,
  FileText,
  Filter,
  Download,
  Eye,
  History,
  Image,
  LayoutDashboard,
  Leaf,
  ListChecks,
  LogOut,
  Map,
  MapPin,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  Send,
  Sprout,
  Trees,
  UploadCloud,
  UserRound,
  Users,
  X,
  XCircle,
} from "lucide-react"

type Role = "masyarakat" | "admin" | "petugas"
type Page = "landing" | "login" | "register" | "dashboard" | "lahan" | "peta" | "detail" | "rekomendasi" | "pengajuan" | "status" | "riwayat" | "perkembangan" | "pengguna" | "verifikasi" | "monitoring" | "riwayat-data" | "laporan" | "profil"

const photos = {
  hero: "https://images.unsplash.com/photo-1721979070958-187960794549?auto=format&fit=crop&w=1400&q=85",
  rungkut:
    "https://images.unsplash.com/photo-1654159163241-e625f3ebe643?auto=format&fit=crop&w=800&q=80",
  gubeng:
    "https://images.unsplash.com/photo-1642484300897-dc766f5c24e5?auto=format&fit=crop&w=800&q=80",
  wonokromo:
    "https://images.unsplash.com/photo-1622123651884-e3d30eebfbff?auto=format&fit=crop&w=800&q=80",
}

const roleLabels: Record<Role, string> = {
  masyarakat: "Masyarakat / Komunitas",
  admin: "Pemerintah / Admin",
  petugas: "Petugas Lapangan",
}

const lands = [
  {
    name: "Lahan Kosong Rungkut",
    address: "Jl. Rungkut Madya, Rungkut",
    area: "1.250 m²",
    condition: "Tanah datar, akses mudah",
    status: "Tersedia",
    image: photos.rungkut,
  },
  {
    name: "Lahan Kelurahan Gubeng",
    address: "Jl. Gubeng Kertajaya, Gubeng",
    area: "860 m²",
    condition: "Perlu pembersihan ringan",
    status: "Diverifikasi",
    image: photos.gubeng,
  },
  {
    name: "Lahan Pinggir Sungai Wonokromo",
    address: "Jl. Jagir Wonokromo, Wonokromo",
    area: "2.100 m²",
    condition: "Lahan memanjang, cukup subur",
    status: "Dalam pemanfaatan",
    image: photos.wonokromo,
  },
]

const menus: Record<Role, { label: string page: Page icon: typeof Leaf }[]> = {
  masyarakat: [
    { label: "Dashboard", page: "dashboard", icon: LayoutDashboard },
    { label: "Data Lahan", page: "lahan", icon: Trees },
    { label: "Peta Lahan", page: "peta", icon: Map },
    { label: "Rekomendasi", page: "rekomendasi", icon: Sprout },
    { label: "Pengajuan Saya", page: "status", icon: FileText },
    { label: "Riwayat Pengajuan", page: "riwayat", icon: History },
    { label: "Perkembangan Kegiatan", page: "perkembangan", icon: Activity },
  ],
  admin: [
    { label: "Dashboard", page: "dashboard", icon: LayoutDashboard },
    { label: "Data Lahan", page: "lahan", icon: Trees },
    { label: "Peta Lahan", page: "peta", icon: Map },
    { label: "Pengajuan", page: "status", icon: FileText },
    { label: "Verifikasi Lapangan", page: "verifikasi", icon: ClipboardCheck },
    { label: "Monitoring", page: "monitoring", icon: Activity },
    { label: "Pengguna", page: "pengguna", icon: Users },
    { label: "Riwayat Data", page: "riwayat-data", icon: FileClock },
  ],
  petugas: [
    { label: "Dashboard", page: "dashboard", icon: LayoutDashboard },
    { label: "Tugas Verifikasi", page: "verifikasi", icon: ClipboardCheck },
    { label: "Monitoring", page: "monitoring", icon: Activity },
    { label: "Laporan Lapangan", page: "laporan", icon: ListChecks },
  ],
}

function Button({
  children,
  variant = "primary",
  className = "",
  onClick,
  type = "button",
}: {
  children: ReactNode
  variant?: "primary" | "secondary" | "ghost" | "danger"
  className?: string
  onClick?: () => void
  type?: "button" | "submit"
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`btn btn-${variant} ${className}`}
    >
      {children}
    </button>
  )
}

function Badge({
  children,
  tone = "green",
}: {
  children: ReactNode
  tone?: string
}) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}

function Logo({
  dark = false,
  variant = "default",
}: {
  dark?: boolean
  variant?: "default" | "header" | "profile"
}) {
  return (
    <div
      className={`logo logo-${variant} ${dark ? "logo-dark" : ""}`}
      aria-label="PERLAHAN — Platform Pengelolaan dan Pemanfaatan Lahan"
    >
      <img
        src="/perlahan-logo.png"
        alt="Logo resmi PERLAHAN — Platform Pengelolaan dan Pemanfaatan Lahan"
      />
    </div>
  )
}

function Landing({ go }: { go: (page: Page) => void }) {
  const features = [
    [
      Map,
      "Peta Lahan",
      "Temukan lahan potensial melalui peta sebaran yang mudah dijelajahi.",
    ],
    [
      Sprout,
      "Rekomendasi",
      "Lihat alternatif pemanfaatan awal sesuai kondisi setiap lahan.",
    ],
    [
      FileText,
      "Pengajuan",
      "Ajukan rencana kegiatan komunitas secara transparan dan terarah.",
    ],
    [
      Activity,
      "Monitoring",
      "Pantau perkembangan kegiatan serta dampaknya bagi lingkungan.",
    ],
  ] as const

  return (
    <div className="landing">
      <nav className="landing-nav">
        <Logo dark />
        <div className="landing-links">
          <a href="#fitur">Fitur</a>
          <a href="#tentang">Tentang</a>
          <a href="#dampak">Dampak</a>
        </div>
        <div className="nav-actions">
          <Button variant="ghost" onClick={() => go("login")}>
            Masuk
          </Button>
          <Button onClick={() => go("register")}>Daftar</Button>
        </div>
      </nav>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <Badge tone="light">
              <Sprout size={14} /> Bersama menjaga ruang hidup Surabaya
            </Badge>
            <h1>
              Lahan tidur, <span>harapan bertumbuh.</span>
            </h1>
            <p>
              Platform kolaborasi untuk mendata, memetakan, dan menghidupkan
              lahan pemerintah yang belum termanfaatkan menjadi ruang hijau
              produktif.
            </p>
            <div className="hero-actions">
              <Button onClick={() => go("login")}>
                Mulai Jelajahi <ChevronRight size={18} />
              </Button>
              <Button variant="secondary" onClick={() => go("peta")}>
                Lihat Peta Lahan
              </Button>
            </div>
            <div className="trust-row">
              <div className="avatar-stack">
                <span>RW</span>
                <span>KT</span>
                <span>+8</span>
              </div>
              <p>
                <strong>10+ komunitas</strong>
                <br />
                siap berkolaborasi
              </p>
            </div>
          </div>
          <div className="hero-visual">
            <img src={photos.hero} alt="Warga merawat kebun hijau bersama" />
            <div className="float-card float-location">
              <MapPin size={20} />
              <div>
                <strong>Rungkut, Surabaya</strong>
                <span>Potensi urban farming</span>
              </div>
            </div>
            <div className="float-card float-impact">
              <span className="impact-icon">
                <Leaf size={20} />
              </span>
              <div>
                <strong>+32%</strong>
                <span>ruang hijau produktif</span>
              </div>
            </div>
          </div>
        </section>

        <section className="stats-strip" id="dampak">
          <div>
            <strong>48</strong>
            <span>Lahan terdata</span>
          </div>
          <div>
            <strong>12,4 Ha</strong>
            <span>Total area potensial</span>
          </div>
          <div>
            <strong>17</strong>
            <span>Kegiatan berjalan</span>
          </div>
          <div>
            <strong>31</strong>
            <span>Komunitas terlibat</span>
          </div>
        </section>

        <section className="features" id="fitur">
          <div className="section-heading">
            <Badge tone="light">Satu platform, dampak nyata</Badge>
            <h2>Dari lahan kosong menjadi ruang yang berarti</h2>
            <p>
              PERLAHAN mendukung kolaborasi warga dan pemerintah dari proses
              penemuan lahan hingga pemantauan kegiatan.
            </p>
          </div>
          <div className="feature-grid">
            {features.map(([Icon, title, copy], index) => (
              <article className="feature-card" key={title}>
                <span className="feature-number">0{index + 1}</span>
                <span className="feature-icon">
                  <Icon size={23} />
                </span>
                <h3>{title}</h3>
                <p>{copy}</p>
                <button
                  className="text-link"
                  onClick={() => go(index === 0 ? "peta" : "login")}
                >
                  Pelajari lebih lanjut <ChevronRight size={15} />
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="mission" id="tentang">
          <div>
            <span className="sdg">SDG 15</span>
            <h2>Menghidupkan ekosistem kota, perlahan namun pasti.</h2>
          </div>
          <p>
            Prototype akademik ini mendukung semangat <em>Life on Land</em>{" "}
            melalui urban farming, penghijauan, dan taman lingkungan di Kota
            Surabaya.
          </p>
        </section>
        <section className="disclaimer">
          <CircleAlert size={17} />
          <span>
            <strong>Catatan:</strong> Rekomendasi hanya informasi awal, bukan
            keputusan akhir.
          </span>
        </section>
      </main>
      <footer>
        <Logo />
        <span>
          Prototype mata kuliah — bukan sistem resmi Pemerintah Kota Surabaya.
        </span>
        <span>© 2025 PERLAHAN</span>
      </footer>
    </div>
  )
}

function Auth({
  page,
  go,
  onLogin,
}: {
  page: "login" | "register"
  go: (p: Page) => void
  onLogin: (r: Role) => void
}) {
  const [role, setRole] = useState<Role>("masyarakat")
  const [submitted, setSubmitted] = useState(false)
  return (
    <div className="auth-page">
      <button className="auth-brand" onClick={() => go("landing")}>
        <Logo dark />
      </button>
      <div className="auth-visual">
        <div className="auth-overlay">
          <Badge tone="light">Surabaya berkelanjutan</Badge>
          <h1>Setiap jengkal lahan punya potensi untuk tumbuh.</h1>
          <p>
            Mari ubah ruang yang terlupakan menjadi manfaat yang dirasakan
            bersama.
          </p>
        </div>
      </div>
      <div className="auth-panel">
        <div className="auth-box">
          <div className="auth-title">
            <span className="eyebrow">
              {page === "login"
                ? "Selamat datang kembali"
                : "Bergabung bersama kami"}
            </span>
            <h2>{page === "login" ? "Masuk ke PERLAHAN" : "Buat akun baru"}</h2>
            <p>
              {page === "login"
                ? "Pilih peran untuk mencoba dashboard prototype."
                : "Isi data untuk mulai berkontribusi pada ruang hijau kota."}
            </p>
          </div>
          {page === "login" && (
            <div className="role-picker">
              {(Object.keys(roleLabels) as Role[]).map((key) => (
                <button
                  key={key}
                  className={role === key ? "active" : ""}
                  onClick={() => setRole(key)}
                >
                  {key === "masyarakat" ? (
                    <Users size={17} />
                  ) : key === "admin" ? (
                    <LayoutDashboard size={17} />
                  ) : (
                    <ClipboardCheck size={17} />
                  )}
                  {key === "masyarakat"
                    ? "Warga"
                    : key === "admin"
                      ? "Admin"
                      : "Petugas"}
                </button>
              ))}
            </div>
          )}
          <form
            onSubmit={(e) => {
              e.preventDefault()
              setSubmitted(true)
              if (page === "login") setTimeout(() => onLogin(role), 450)
            }}
          >
            {page === "register" && (
              <Field label="Nama lengkap" placeholder="Contoh: Siti Rahma" />
            )}
            <Field label="Email" placeholder="nama@email.com" type="email" />
            {page === "register" && (
              <Field label="Nomor HP" placeholder="08xxxxxxxxxx" />
            )}
            <Field
              label="Password"
              placeholder="Minimal 8 karakter"
              type="password"
            />
            {page === "register" && (
              <Field
                label="Konfirmasi password"
                placeholder="Ulangi password"
                type="password"
              />
            )}
            {submitted && page === "register" && (
              <div className="form-success">
                <CheckCircle2 size={17} /> Pendaftaran berhasil. Silakan masuk.
              </div>
            )}
            <Button type="submit" className="btn-block">
              {page === "login" ? "Masuk" : "Daftar"} <ChevronRight size={17} />
            </Button>
          </form>
          <p className="auth-switch">
            {page === "login" ? "Belum memiliki akun?" : "Sudah memiliki akun?"}{" "}
            <button onClick={() => go(page === "login" ? "register" : "login")}>
              {page === "login" ? "Daftar sekarang" : "Masuk"}
            </button>
          </p>
          <div className="prototype-note">
            <CircleAlert size={15} /> Gunakan peran di atas untuk menjelajahi
            seluruh alur prototype.
          </div>
        </div>
      </div>
    </div>
  )
}

function Field({
  label,
  placeholder,
  type = "text",
  children,
}: {
  label: string
  placeholder?: string
  type?: string
  children?: ReactNode
}) {
  return (
    <label className="field">
      <span>{label}</span>
      {children || <input type={type} placeholder={placeholder} />}
    </label>
  )
}

function Sidebar({
  role,
  page,
  go,
  open,
  close,
}: {
  role: Role
  page: Page
  go: (p: Page) => void
  open: boolean
  close: () => void
}) {
  return (
    <>
      {open && (
        <button
          className="sidebar-scrim"
          onClick={close}
          aria-label="Tutup menu"
        />
      )}
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="side-head">
          <Logo />
          <button onClick={close}>
            <X size={20} />
          </button>
        </div>
        <div className="role-label">
          <span>
            {role === "admin" ? "PA" : role === "petugas" ? "PL" : "MK"}
          </span>
          <div>
            <strong>{roleLabels[role]}</strong>
            <small>Portal PERLAHAN</small>
          </div>
        </div>
        <nav>
          <p>MENU UTAMA</p>
          {menus[role].map(({ label, page: target, icon: Icon }) => (
            <button
              key={label}
              className={page === target ? "active" : ""}
              onClick={() => {
                go(target)
                close()
              }}
            >
              <Icon size={19} />
              <span>{label}</span>
              {page === target && <i />}
            </button>
          ))}
        </nav>
        <div className="side-foot">
          <div className="sdg-mini">
            <Leaf size={18} />
            <div>
              <strong>Mendukung SDG 15</strong>
              <span>Life on Land</span>
            </div>
          </div>
          <button onClick={() => go("landing")}>
            <LogOut size={18} /> Keluar
          </button>
        </div>
      </aside>
    </>
  )
}

function AppShell({
  role,
  page,
  go,
  children,
}: {
  role: Role
  page: Page
  go: (p: Page) => void
  children: ReactNode
}) {
  const [menuOpen, setMenuOpen] = useState(false)
  const title =
    menus[role].find((m) => m.page === page)?.label ||
    (page === "detail"
      ? "Detail Lahan"
      : page === "pengajuan"
        ? "Pengajuan Pemanfaatan"
        : "PERLAHAN")
  return (
    <div className="app-shell">
      <Sidebar
        role={role}
        page={page}
        go={go}
        open={menuOpen}
        close={() => setMenuOpen(false)}
      />
      <div className="app-main">
        <header className="topbar">
          <div className="topbar-left">
            <button className="menu-btn" onClick={() => setMenuOpen(true)}>
              <Menu size={21} />
            </button>
            {(role === "admin" || role === "petugas") && (
              <Logo variant="header" />
            )}
            <div>
              <span className="breadcrumb">Portal / {title}</span>
              <strong>{title}</strong>
            </div>
          </div>
          <div className="topbar-actions">
            <label className="top-search">
              <Search size={18} />
              <input placeholder="Cari data, lahan..." />
            </label>
            <button className="icon-btn">
              <Bell size={20} />
              <i />
            </button>
            <button className="profile" onClick={() => go("profil")}>
              <span>
                {role === "admin" ? "AR" : role === "petugas" ? "BW" : "SR"}
              </span>
              <div>
                <strong>
                  {role === "admin"
                    ? "Arif Rahman"
                    : role === "petugas"
                      ? "Budi Wibowo"
                      : "Siti Rahma"}
                </strong>
                <small>{roleLabels[role]}</small>
              </div>
              <ChevronDown size={16} />
            </button>
          </div>
        </header>
        <main className="content">{children}</main>
      </div>
    </div>
  )
}

function StatCard({
  label,
  value,
  note,
  icon: Icon,
  tone = "green",
}: {
  label: string
  value: string
  note: string
  icon: typeof Leaf
  tone?: string
}) {
  return (
    <article className="stat-card">
      <span className={`stat-icon ${tone}`}>
        <Icon size={21} />
      </span>
      <div>
        <p>{label}</p>
        <strong>{value}</strong>
        <small>{note}</small>
      </div>
      <MoreHorizontal size={18} className="stat-more" />
    </article>
  )
}

function Dashboard({ role, go }: { role: Role go: (p: Page) => void }) {
  if (role === "admin") return <AdminDashboard go={go} />
  if (role === "petugas") return <OfficerDashboard go={go} />
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">Rabu, 21 Mei 2025</span>
          <h1>Selamat datang kembali, Siti!</h1>
          <p>Pantau pengajuan dan temukan peluang baru untuk komunitas Anda.</p>
        </div>
        <Button onClick={() => go("lahan")}>
          <Plus size={18} /> Buat Pengajuan
        </Button>
      </div>
      <div className="stats-grid four">
        <StatCard
          label="Pengajuan Aktif"
          value="04"
          note="+1 bulan ini"
          icon={FileText}
        />
        <StatCard
          label="Menunggu"
          value="02"
          note="Sedang ditinjau"
          icon={Clock3}
          tone="yellow"
        />
        <StatCard
          label="Disetujui"
          value="01"
          note="Siap dilaksanakan"
          icon={CheckCircle2}
          tone="blue"
        />
        <StatCard
          label="Perlu Perbaikan"
          value="01"
          note="Perlu tindakan"
          icon={CircleAlert}
          tone="orange"
        />
      </div>
      <div className="alert-banner">
        <span>
          <CircleAlert size={20} />
        </span>
        <div>
          <strong>Satu pengajuan perlu diperbaiki</strong>
          <p>
            Admin memberikan catatan pada pengajuan “Kebun Komunitas Rungkut”.
          </p>
        </div>
        <Button variant="secondary" onClick={() => go("status")}>
          Lihat Catatan
        </Button>
      </div>
      <SectionHeader
        title="Rekomendasi lahan untuk Anda"
        text="Berdasarkan lokasi dan minat komunitas"
        action="Lihat semua"
        onClick={() => go("lahan")}
      />
      <div className="land-grid compact">
        {lands.map((land, index) => (
          <LandCard
            key={land.name}
            land={land}
            onClick={() => go("detail")}
            featured={index === 0}
          />
        ))}
      </div>
      <SectionHeader
        title="Pengajuan terbaru"
        text="Aktivitas pengajuan komunitas Anda"
        action="Lihat riwayat"
        onClick={() => go("riwayat")}
      />
      <SubmissionTable role={role} go={go} />
    </>
  )
}

function AdminDashboard({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">RINGKASAN HARI INI</span>
          <h1>Selamat pagi, Arif</h1>
          <p>Berikut kondisi pemanfaatan lahan Kota Surabaya hari ini.</p>
        </div>
        <Button onClick={() => go("lahan")}>
          <Plus size={18} /> Tambah Lahan
        </Button>
      </div>
      <div className="stats-grid five">
        <StatCard
          label="Total Lahan"
          value="48"
          note="+3 bulan ini"
          icon={Trees}
        />
        <StatCard
          label="Lahan Tersedia"
          value="21"
          note="43,7% dari total"
          icon={MapPin}
        />
        <StatCard
          label="Pengajuan Masuk"
          value="16"
          note="+5 minggu ini"
          icon={FileText}
          tone="blue"
        />
        <StatCard
          label="Perlu Verifikasi"
          value="07"
          note="Butuh tindakan"
          icon={ClipboardCheck}
          tone="yellow"
        />
        <StatCard
          label="Kegiatan Berjalan"
          value="12"
          note="Rata-rata 68%"
          icon={Activity}
          tone="orange"
        />
      </div>
      <div className="dashboard-grid">
        <section className="panel chart-panel">
          <SectionHeader
            title="Perkembangan Pengajuan"
            text="Januari — Juni 2025"
            action="6 bulan terakhir"
          />
          <div className="bar-chart">
            {[38, 55, 43, 72, 62, 86].map((h, i) => (
              <div key={i}>
                <span style={{ height: `${h}%` }} />
                <small>{["Jan", "Feb", "Mar", "Apr", "Mei", "Jun"][i]}</small>
              </div>
            ))}
          </div>
        </section>
        <section className="panel donut-panel">
          <SectionHeader title="Status Lahan" text="Distribusi 48 lahan" />
          <div className="donut-wrap">
            <div className="donut">
              <span>
                <strong>48</strong>
                <small>Total</small>
              </span>
            </div>
            <div className="legend">
              <span>
                <i className="available" />
                Tersedia <strong>21</strong>
              </span>
              <span>
                <i className="used" />
                Dimanfaatkan <strong>17</strong>
              </span>
              <span>
                <i className="review" />
                Verifikasi <strong>10</strong>
              </span>
            </div>
          </div>
        </section>
      </div>
      <div className="dashboard-grid">
        <section className="panel map-mini">
          <SectionHeader
            title="Sebaran Lahan"
            text="Kota Surabaya"
            action="Buka peta"
            onClick={() => go("peta")}
          />
          <MapCanvas small />
        </section>
        <section className="panel">
          <SectionHeader
            title="Aktivitas Terbaru"
            text="Pembaruan sistem hari ini"
          />
          <ActivityList />
        </section>
      </div>
    </>
  )
}

function OfficerDashboard({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">Rabu, 21 Mei 2025</span>
          <h1>Selamat bertugas, Budi!</h1>
          <p>Anda memiliki 3 tugas lapangan yang perlu ditindaklanjuti.</p>
        </div>
        <Button onClick={() => go("verifikasi")}>Lihat Semua Tugas</Button>
      </div>
      <div className="stats-grid four">
        <StatCard
          label="Tugas Baru"
          value="03"
          note="2 mendekati tenggat"
          icon={Bell}
          tone="orange"
        />
        <StatCard
          label="Dikerjakan"
          value="02"
          note="Verifikasi berjalan"
          icon={Clock3}
          tone="blue"
        />
        <StatCard
          label="Selesai"
          value="14"
          note="Bulan ini"
          icon={CheckCircle2}
        />
        <StatCard
          label="Monitoring Aktif"
          value="05"
          note="Kegiatan dipantau"
          icon={Activity}
        />
      </div>
      <SectionHeader
        title="Tugas Terbaru"
        text="Prioritaskan tugas dengan tenggat terdekat"
        action="Lihat semua"
        onClick={() => go("verifikasi")}
      />
      <TaskTable go={go} />
    </>
  )
}

function SectionHeader({
  title,
  text,
  action,
  onClick,
}: {
  title: string
  text?: string
  action?: string
  onClick?: () => void
}) {
  return (
    <div className="section-header">
      <div>
        <h2>{title}</h2>
        {text && <p>{text}</p>}
      </div>
      {action && (
        <button onClick={onClick}>
          {action}
          <ChevronRight size={15} />
        </button>
      )}
    </div>
  )
}

function LandCard({
  land,
  onClick,
  featured,
}: {
  land: typeof lands[number]
  onClick: () => void
  featured?: boolean
}) {
  return (
    <article className="land-card">
      <div className="land-image">
        <img src={land.image} alt={land.name} />
        <Badge
          tone={
            land.status === "Tersedia"
              ? "green"
              : land.status === "Diverifikasi"
                ? "blue"
                : "yellow"
          }
        >
          {land.status}
        </Badge>
        {featured && <span className="match">92% cocok</span>}
      </div>
      <div className="land-body">
        <div>
          <h3>{land.name}</h3>
          <p>
            <MapPin size={15} />
            {land.address}
          </p>
        </div>
        <div className="land-meta">
          <span>
            <strong>{land.area}</strong>Luas lahan
          </span>
          <span>
            <strong>{land.condition.split(",")[0]}</strong>Kondisi
          </span>
        </div>
        <Button variant="secondary" onClick={onClick}>
          Lihat Detail <ChevronRight size={16} />
        </Button>
      </div>
    </article>
  )
}

function LandsPage({ role, go }: { role: Role go: (p: Page) => void }) {
  const [query, setQuery] = useState("")
  const filtered = lands.filter((l) =>
    l.name.toLowerCase().includes(query.toLowerCase()),
  )
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">INVENTARIS RUANG KOTA</span>
          <h1>Data Lahan</h1>
          <p>Jelajahi lahan pemerintah yang berpotensi dimanfaatkan bersama.</p>
        </div>
        {role === "admin" && (
          <Button>
            <Plus size={18} /> Tambah Lahan
          </Button>
        )}
      </div>
      <div className="filter-bar">
        <label>
          <Search size={18} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari nama atau alamat lahan..."
          />
        </label>
        <Button variant="secondary">
          <MapPin size={17} /> Semua Lokasi <ChevronDown size={15} />
        </Button>
        <Button variant="secondary">
          <Filter size={17} /> Status <ChevronDown size={15} />
        </Button>
        <Button variant="secondary">
          Luas Lahan <ChevronDown size={15} />
        </Button>
      </div>
      <div className="results-head">
        <p>
          Menampilkan <strong>{filtered.length} lahan</strong> potensial
        </p>
        <button>
          Urutkan: Terbaru <ChevronDown size={15} />
        </button>
      </div>
      {filtered.length ? (
        <div className="land-grid">
          {filtered.map((land) => (
            <LandCard
              key={land.name}
              land={land}
              onClick={() => go("detail")}
            />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <Search size={32} />
          <h3>Data tidak ditemukan</h3>
          <p>Coba ubah kata kunci atau filter pencarian Anda.</p>
          <Button variant="secondary" onClick={() => setQuery("")}>
            Atur Ulang Filter
          </Button>
        </div>
      )}
    </>
  )
}

function DetailPage({ go }: { go: (p: Page) => void }) {
  const [tab, setTab] = useState<"info" | "rekomendasi">("info")
  return (
    <>
      <button className="back-link" onClick={() => go("lahan")}>
        <ChevronRight size={17} /> Kembali ke Data Lahan
      </button>
      <div className="detail-hero">
        <div className="gallery-main">
          <img src={photos.rungkut} alt="Lahan Kosong Rungkut" />
          <Badge tone="green">Tersedia</Badge>
        </div>
        <div className="gallery-side">
          <img src={photos.gubeng} alt="Detail vegetasi lahan" />
          <img src={photos.wonokromo} alt="Akses menuju lahan" />
          <button>
            <Image size={17} /> Lihat 6 foto
          </button>
        </div>
      </div>
      <div className="detail-layout">
        <div>
          <div className="detail-heading">
            <span className="eyebrow">ID LAHAN • SBY-RKT-024</span>
            <h1>Lahan Kosong Rungkut</h1>
            <p>
              <MapPin size={17} /> Jl. Rungkut Madya No. 17, Kel. Rungkut Kidul,
              Surabaya
            </p>
          </div>
          <div className="tabs">
            <button
              className={tab === "info" ? "active" : ""}
              onClick={() => setTab("info")}
            >
              Informasi
            </button>
            <button
              className={tab === "rekomendasi" ? "active" : ""}
              onClick={() => setTab("rekomendasi")}
            >
              Rekomendasi
            </button>
          </div>
          {tab === "info" ? (
            <section className="panel detail-panel">
              <h2>Informasi Lahan</h2>
              <div className="info-grid">
                <div>
                  <span>Luas lahan</span>
                  <strong>1.250 m²</strong>
                </div>
                <div>
                  <span>Kondisi</span>
                  <strong>Tanah datar</strong>
                </div>
                <div>
                  <span>Akses jalan</span>
                  <strong>Mudah diakses</strong>
                </div>
                <div>
                  <span>Kepemilikan</span>
                  <strong>Pemerintah Kota</strong>
                </div>
              </div>
              <h3>Deskripsi</h3>
              <p>
                Lahan terbuka dengan permukaan relatif datar dan paparan
                matahari yang baik. Memiliki akses air dari saluran lingkungan,
                cocok untuk kegiatan produktif skala komunitas.
              </p>
            </section>
          ) : (
            <Recommendations />
          )}
        </div>
        <aside className="detail-aside">
          <section className="panel action-card">
            <span className="feature-icon">
              <Sprout size={23} />
            </span>
            <h2>Tertarik memanfaatkan lahan ini?</h2>
            <p>
              Ajukan rencana kegiatan komunitas Anda untuk ditinjau oleh
              pengelola.
            </p>
            <Button className="btn-block" onClick={() => go("pengajuan")}>
              Ajukan Pemanfaatan <ChevronRight size={17} />
            </Button>
            <small>
              <Clock3 size={14} /> Estimasi peninjauan 5–7 hari kerja
            </small>
          </section>
          <section className="panel mini-location">
            <SectionHeader
              title="Lokasi Lahan"
              action="Buka peta"
              onClick={() => go("peta")}
            />
            <MapCanvas small />
          </section>
        </aside>
      </div>
    </>
  )
}

function Recommendations() {
  const items = [
    [
      Sprout,
      "Urban Farming",
      "Sangat direkomendasikan",
      "Paparan matahari optimal, akses air tersedia, dan dekat dengan permukiman warga.",
    ],
    [
      Trees,
      "Taman Lingkungan",
      "Direkomendasikan",
      "Luas memadai untuk area bermain hijau dan ruang interaksi antarwarga.",
    ],
    [
      Leaf,
      "Penghijauan",
      "Alternatif sesuai",
      "Dapat membantu meningkatkan tutupan hijau dan resapan air kawasan.",
    ],
  ] as const
  return (
    <section className="recommend-list">
      {items.map(([Icon, title, status, copy]) => (
        <article className="panel recommendation" key={title}>
          <span>
            <Icon size={24} />
          </span>
          <div>
            <Badge tone="light">{status}</Badge>
            <h3>{title}</h3>
            <p>{copy}</p>
            <button>
              Pelajari pertimbangan <ChevronRight size={15} />
            </button>
          </div>
        </article>
      ))}
      <div className="disclaimer">
        <CircleAlert size={17} />
        <span>
          Rekomendasi hanya informasi awal berdasarkan data lahan, bukan
          keputusan akhir.
        </span>
      </div>
    </section>
  )
}

function MapPage({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">EKSPLORASI WILAYAH</span>
          <h1>Peta Sebaran Lahan</h1>
          <p>Temukan lahan potensial di berbagai kecamatan Kota Surabaya.</p>
        </div>
      </div>
      <div className="map-toolbar">
        <label>
          <Search size={16} />
          <input placeholder="Cari lokasi atau nama lahan..." />
        </label>
        <select aria-label="Filter kecamatan">
          <option>Semua Kecamatan</option>
          <option>Rungkut</option>
          <option>Gubeng</option>
        </select>
        <div className="status-chips">
          <button className="active">
            <i className="dot available" /> Tersedia
          </button>
          <button>
            <i className="dot verified" /> Diverifikasi
          </button>
          <button>
            <i className="dot used" /> Dimanfaatkan
          </button>
        </div>
        <span className="map-count">48 lahan</span>
      </div>
      <MapCanvas onDetail={() => go("detail")} />
    </>
  )
}

function MapCanvas({
  small = false,
  onDetail,
}: {
  small?: boolean
  onDetail?: () => void
}) {
  return (
    <div className={`map-canvas ${small ? "small" : ""}`}>
      <div className="map-grid" />
      <span className="road road-one">Jl. Ahmad Yani</span>
      <span className="road road-two">Jl. Dr. Ir. Soekarno</span>
      {!small && (
        <>
          <button className="zoom plus">+</button>
          <button className="zoom minus">−</button>
        </>
      )}
      <button className="marker marker-one">
        <MapPin size={21} fill="currentColor" />
      </button>
      <button className="marker marker-two">
        <MapPin size={21} fill="currentColor" />
      </button>
      <button className="marker marker-three">
        <MapPin size={21} fill="currentColor" />
      </button>
      {!small && (
        <div className="map-popup">
          <div>
            <strong>Lahan Kosong Rungkut</strong>
            <span>1.250 m² • Rungkut</span>
            <small>
              <i className="dot available" /> Tersedia
            </small>
            <button onClick={onDetail}>
              Detail <ChevronRight size={13} />
            </button>
          </div>
        </div>
      )}
      <div className="map-attribution">© OpenStreetMap contributors</div>
    </div>
  )
}

function ApplicationForm({ go }: { go: (p: Page) => void }) {
  const [sent, setSent] = useState(false)
  if (sent)
    return (
      <div className="success-page">
        <span>
          <Check size={34} />
        </span>
        <Badge tone="light">Status: Diajukan</Badge>
        <h1>Pengajuan berhasil dikirim</h1>
        <p>
          Pengajuan “Kebun Pangan Rungkut” telah diterima dan akan ditinjau oleh
          admin dalam 5–7 hari kerja.
        </p>
        <div className="reference">
          <span>Nomor Pengajuan</span>
          <strong>PGJ-2025-0058</strong>
        </div>
        <Button onClick={() => go("status")}>Pantau Status Pengajuan</Button>
        <Button variant="ghost" onClick={() => go("dashboard")}>
          Kembali ke Dashboard
        </Button>
      </div>
    )
  return (
    <>
      <button className="back-link" onClick={() => go("detail")}>
        <ChevronRight size={17} /> Kembali ke Detail Lahan
      </button>
      <div className="page-intro">
        <div>
          <span className="eyebrow">LANGKAH 1 DARI 2</span>
          <h1>Ajukan Pemanfaatan Lahan</h1>
          <p>
            Lengkapi rencana kegiatan komunitas Anda dengan informasi yang
            jelas.
          </p>
        </div>
      </div>
      <form
        className="form-layout"
        onSubmit={(e) => {
          e.preventDefault()
          setSent(true)
        }}
      >
        <section className="panel form-card">
          <div className="form-section-title">
            <span>1</span>
            <div>
              <h2>Lahan Terpilih</h2>
              <p>Pastikan lahan yang dipilih sudah sesuai.</p>
            </div>
          </div>
          <div className="selected-land">
            <img src={photos.rungkut} alt="" />
            <div>
              <Badge tone="green">Tersedia</Badge>
              <h3>Lahan Kosong Rungkut</h3>
              <p>
                <MapPin size={14} /> Jl. Rungkut Madya • 1.250 m²
              </p>
            </div>
            <CheckCircle2 size={22} />
          </div>
          <div className="form-section-title">
            <span>2</span>
            <div>
              <h2>Rencana Kegiatan</h2>
              <p>Ceritakan kegiatan yang ingin Anda jalankan.</p>
            </div>
          </div>
          <Field
            label="Nama kegiatan *"
            placeholder="Contoh: Kebun Pangan Warga Rungkut"
          />
          <Field label="Deskripsi dan rencana kegiatan *">
            <textarea
              placeholder="Jelaskan tujuan, aktivitas, penerima manfaat, dan rencana pengelolaan..."
              rows={6}
            />
          </Field>
          <div className="form-row">
            <Field label="Tanggal pengajuan *">
              <input type="date" defaultValue="2025-05-21" />
            </Field>
            <Field label="Jenis pemanfaatan *">
              <select defaultValue="">
                <option value="" disabled>
                  Pilih jenis kegiatan
                </option>
                <option>Urban Farming</option>
                <option>Taman Lingkungan</option>
              </select>
            </Field>
          </div>
          <Field label="Dokumen / foto pendukung">
            <div className="upload-zone">
              <UploadCloud size={28} />
              <strong>Tarik file ke sini atau pilih file</strong>
              <span>PDF, JPG, PNG • Maksimal 5 MB per file</span>
              <Button variant="secondary">Pilih File</Button>
            </div>
          </Field>
          <div className="form-actions">
            <Button variant="ghost" onClick={() => go("detail")}>
              Simpan Draft
            </Button>
            <Button type="submit">
              Kirim Pengajuan <Send size={17} />
            </Button>
          </div>
        </section>
        <aside className="panel tips-card">
          <span>
            <MessageSquareText size={21} />
          </span>
          <h3>Tips pengajuan yang baik</h3>
          <ul>
            <li>Jelaskan manfaat kegiatan bagi warga.</li>
            <li>Sertakan jadwal pelaksanaan.</li>
            <li>Unggah proposal atau dokumentasi.</li>
            <li>Pastikan kontak komunitas aktif.</li>
          </ul>
          <div>
            <CircleAlert size={16} />
            Data belum lengkap akan disimpan sebagai draft.
          </div>
        </aside>
      </form>
    </>
  )
}

function SubmissionTable({ role, go }: { role: Role go: (p: Page) => void }) {
  const rows =
    role === "admin"
      ? [
          [
            "Siti Rahma",
            "Lahan Kosong Rungkut",
            "Kebun Pangan Warga",
            "21 Mei 2025",
            "Diajukan",
          ],
          [
            "Komunitas Hijau",
            "Lahan Kelurahan Gubeng",
            "Taman Baca Hijau",
            "19 Mei 2025",
            "Diverifikasi",
          ],
          [
            "Karang Taruna Jagir",
            "Pinggir Sungai Wonokromo",
            "Koridor Hijau Jagir",
            "16 Mei 2025",
            "Perlu Perbaikan",
          ],
        ]
      : [
          [
            "PGJ-2025-0058",
            "Lahan Kosong Rungkut",
            "Kebun Pangan Warga",
            "21 Mei 2025",
            "Diajukan",
          ],
          [
            "PGJ-2025-0041",
            "Lahan Kelurahan Gubeng",
            "Taman Baca Hijau",
            "10 Mei 2025",
            "Perlu Perbaikan",
          ],
          [
            "PGJ-2025-0019",
            "Pinggir Sungai Wonokromo",
            "Koridor Hijau Jagir",
            "2 Apr 2025",
            "Disetujui",
          ],
        ]
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {(role === "admin"
              ? ["Pengaju", "Lahan", "Kegiatan", "Tanggal", "Status", "Aksi"]
              : ["ID", "Lahan", "Kegiatan", "Tanggal", "Status", "Aksi"]
            ).map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row[0]}>
              {row.map((cell, i) => (
                <td key={cell}>
                  {i === 4 ? <StatusBadge status={cell} /> : cell}
                </td>
              ))}
              <td>
                <button
                  onClick={() => go(role === "admin" ? "verifikasi" : "status")}
                  className="table-action"
                >
                  Lihat <ChevronRight size={14} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const tone =
    status.includes("Setuju") || status === "Selesai"
      ? "green"
      : status.includes("Tolak")
        ? "red"
        : status.includes("Diverifikasi")
          ? "blue"
          : status.includes("Perbaikan") || status.includes("Proses")
            ? "yellow"
            : "gray"
  return <Badge tone={tone}>{status}</Badge>
}

function StatusPage({ role, go }: { role: Role go: (p: Page) => void }) {
  if (role === "admin") return <AdminSubmissions go={go} />
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">PENGAJUAN SAYA</span>
          <h1>Status Pengajuan</h1>
          <p>Pantau proses peninjauan dan tindak lanjut pengajuan Anda.</p>
        </div>
        <Button onClick={() => go("lahan")}>
          <Plus size={18} /> Pengajuan Baru
        </Button>
      </div>
      <div className="submission-cards">
        {[
          [
            "Kebun Pangan Warga Rungkut",
            "PGJ-2025-0058",
            "Diajukan",
            "Pengajuan diterima sistem",
          ],
          [
            "Taman Baca Hijau Gubeng",
            "PGJ-2025-0041",
            "Perlu Perbaikan",
            "Lengkapi jadwal dan struktur pengelola",
          ],
          [
            "Koridor Hijau Jagir",
            "PGJ-2025-0019",
            "Disetujui",
            "Kegiatan dapat segera dilaksanakan",
          ],
        ].map(([title, id, status, note], idx) => (
          <article className="panel submission-card" key={id}>
            <div className="submission-top">
              <div>
                <span>{id}</span>
                <h2>{title}</h2>
                <p>
                  <MapPin size={15} /> {lands[idx].name}
                </p>
              </div>
              <StatusBadge status={status} />
            </div>
            {status === "Perlu Perbaikan" && (
              <div className="admin-note">
                <CircleAlert size={18} />
                <div>
                  <strong>Catatan Admin</strong>
                  <p>{note}. Kirim perbaikan sebelum 28 Mei 2025.</p>
                </div>
                <Button variant="secondary">Perbaiki</Button>
              </div>
            )}
            <div className="timeline">
              <div className="done">
                <i>
                  <Check size={13} />
                </i>
                <span>
                  Diajukan<small>21 Mei</small>
                </span>
              </div>
              <hr className="done" />
              <div className={status !== "Diajukan" ? "done" : ""}>
                <i>{status !== "Diajukan" ? <Check size={13} /> : "2"}</i>
                <span>
                  Ditinjau
                  <small>{status === "Diajukan" ? "Menunggu" : "22 Mei"}</small>
                </span>
              </div>
              <hr className={status === "Disetujui" ? "done" : ""} />
              <div className={status === "Disetujui" ? "done" : ""}>
                <i>{status === "Disetujui" ? <Check size={13} /> : "3"}</i>
                <span>
                  Keputusan
                  <small>{status === "Disetujui" ? "Disetujui" : "—"}</small>
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </>
  )
}

function AdminSubmissions({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">PENGELOLAAN PENGAJUAN</span>
          <h1>Daftar Pengajuan</h1>
          <p>
            Tinjau, verifikasi, dan berikan keputusan atas rencana pemanfaatan.
          </p>
        </div>
      </div>
      <div className="filter-bar">
        <label>
          <Search size={18} />
          <input placeholder="Cari pengaju, lahan, kegiatan..." />
        </label>
        <Button variant="secondary">
          <Filter size={17} /> Semua Status <ChevronDown size={15} />
        </Button>
      </div>
      <SubmissionTable role="admin" go={go} />
    </>
  )
}

function LegacyVerificationPage({ role }: { role: Role }) {
  const [saved, setSaved] = useState(false)
  if (role === "admin")
    return (
      <>
        <div className="page-intro">
          <div>
            <span className="eyebrow">VERIFIKASI LAPANGAN</span>
            <h1>Penugasan Petugas</h1>
            <p>Kelola penugasan dan tinjau hasil pemeriksaan lapangan.</p>
          </div>
          <Button>
            <Plus size={18} /> Buat Penugasan
          </Button>
        </div>
        <TaskTable />
        <div className="dashboard-grid">
          <section className="panel form-card">
            <SectionHeader
              title="Buat Penugasan"
              text="Tetapkan petugas dan jadwal pemeriksaan"
            />
            <Field label="Pilih pengajuan">
              <select>
                <option>PGJ-2025-0058 — Kebun Pangan Rungkut</option>
              </select>
            </Field>
            <Field label="Pilih petugas">
              <select>
                <option>Budi Wibowo — Surabaya Timur</option>
              </select>
            </Field>
            <div className="form-row">
              <Field label="Tanggal tugas">
                <input type="date" defaultValue="2025-05-23" />
              </Field>
              <Field label="Tenggat">
                <input type="date" defaultValue="2025-05-26" />
              </Field>
            </div>
            <Field label="Catatan tugas">
              <textarea rows={3} placeholder="Fokus pemeriksaan..." />
            </Field>
            <Button>Tugaskan Petugas</Button>
          </section>
          <section className="panel">
            <SectionHeader
              title="Hasil Terbaru"
              text="Verifikasi PGJ-2025-0039"
            />
            <div className="result-box">
              <CheckCircle2 size={28} />
              <Badge tone="green">Sesuai</Badge>
              <h3>Kondisi lahan sesuai data</h3>
              <p>
                Akses lahan baik, sumber air tersedia, dan tidak ditemukan
                kendala kepemilikan.
              </p>
              <div className="proof-grid">
                <img src={photos.rungkut} alt="" />
                <img src={photos.gubeng} alt="" />
              </div>
            </div>
          </section>
        </div>
      </>
    )
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">TUGAS #VRF-2025-028</span>
          <h1>Verifikasi Lahan Rungkut</h1>
          <p>Pengajuan Kebun Pangan Warga • Tenggat 26 Mei 2025</p>
        </div>
        <Badge tone="yellow">Dalam Proses</Badge>
      </div>
      <div className="form-layout">
        <section className="panel form-card">
          <div className="form-section-title">
            <span>1</span>
            <div>
              <h2>Hasil Pemeriksaan</h2>
              <p>Catat kondisi aktual yang Anda temukan.</p>
            </div>
          </div>
          <div className="form-row">
            <Field label="Tanggal verifikasi">
              <input type="date" defaultValue="2025-05-23" />
            </Field>
            <Field label="Hasil pemeriksaan">
              <select>
                <option>Sesuai</option>
                <option>Belum Sesuai</option>
              </select>
            </Field>
          </div>
          <Field label="Catatan pemeriksaan *">
            <textarea
              rows={5}
              placeholder="Jelaskan kondisi lahan, akses, dan temuan lapangan..."
            />
          </Field>
          <Field label="Foto bukti">
            <div className="upload-zone">
              <Camera size={28} />
              <strong>Unggah foto lapangan</strong>
              <span>JPG atau PNG • Maksimal 10 foto</span>
              <Button variant="secondary">Pilih Foto</Button>
            </div>
          </Field>
          <label className="constraint">
            <input type="checkbox" /> Lokasi tidak dapat diakses / terdapat
            kendala
          </label>
          {saved && (
            <div className="form-success">
              <CheckCircle2 size={17} /> Laporan verifikasi berhasil disimpan.
            </div>
          )}
          <div className="form-actions">
            <Button variant="ghost">Simpan Draft</Button>
            <Button onClick={() => setSaved(true)}>
              Simpan Hasil <Check size={17} />
            </Button>
          </div>
        </section>
        <aside className="panel task-summary">
          <h2>Ringkasan Lokasi</h2>
          <img src={photos.rungkut} alt="" />
          <h3>Lahan Kosong Rungkut</h3>
          <p>
            <MapPin size={15} /> Jl. Rungkut Madya, Surabaya
          </p>
          <div className="info-list">
            <span>
              <small>Luas</small>
              <strong>1.250 m²</strong>
            </span>
            <span>
              <small>Kondisi data</small>
              <strong>Tanah datar</strong>
            </span>
            <span>
              <small>Rencana</small>
              <strong>Urban Farming</strong>
            </span>
          </div>
          <MapCanvas small />
        </aside>
      </div>
    </>
  )
}

function Modal({
  title,
  text,
  children,
  onClose,
}: {
  title: string
  text?: string
  children: ReactNode
  onClose: () => void
}) {
  return (
    <div className="modal-backdrop" role="presentation">
      <section className="modal-card" role="dialog" aria-modal="true">
        <div className="modal-head">
          <div>
            <h2>{title}</h2>
            {text && <p>{text}</p>}
          </div>
          <button onClick={onClose} aria-label="Tutup modal">
            <X size={19} />
          </button>
        </div>
        {children}
      </section>
    </div>
  )
}

function AdminVerificationPage() {
  const [tab, setTab] = useState<"assign" | "active" | "result">("assign")
  const [assignmentOpen, setAssignmentOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [decision, setDecision] =
    useState<"approve" | "reject" | "revise" | "repeat" | null>(null)
  const [toast, setToast] = useState("")

  const finishDecision = () => {
    const labels = {
      approve: "Pengajuan berhasil disetujui",
      reject: "Pengajuan berhasil ditolak",
      revise: "Permintaan perbaikan berhasil dikirim",
      repeat: "Verifikasi ulang berhasil ditugaskan",
    }
    if (decision) setToast(labels[decision])
    setDecision(null)
    setTimeout(() => setToast(""), 2800)
  }

  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">VERIFIKASI LAPANGAN</span>
          <h1>Kelola Verifikasi</h1>
          <p>Atur petugas, pantau proses, dan putuskan hasil pemeriksaan.</p>
        </div>
      </div>
      <div className="workflow-tabs">
        <button
          className={tab === "assign" ? "active" : ""}
          onClick={() => setTab("assign")}
        >
          Perlu Penugasan <span>4</span>
        </button>
        <button
          className={tab === "active" ? "active" : ""}
          onClick={() => setTab("active")}
        >
          Sedang Berjalan <span>6</span>
        </button>
        <button
          className={tab === "result" ? "active" : ""}
          onClick={() => setTab("result")}
        >
          Hasil Verifikasi <span>3</span>
        </button>
      </div>
      <div className="filter-bar">
        <label>
          <Search size={17} />
          <input placeholder="Cari nomor pengajuan atau lahan..." />
        </label>
        <Button variant="secondary">
          <Filter size={16} /> Filter
        </Button>
      </div>
      {tab === "assign" && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {[
                  "Pengajuan",
                  "Pemohon",
                  "Lahan",
                  "Kegiatan",
                  "Lengkap Sejak",
                  "Aksi",
                ].map((head) => (
                  <th key={head}>{head}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                [
                  "PGJ-2025-0058",
                  "Siti Rahma",
                  "Lahan Kosong Rungkut",
                  "Kebun Pangan Warga",
                  "21 Mei 2025",
                ],
                [
                  "PGJ-2025-0054",
                  "RW 08 Gubeng",
                  "Lahan Kelurahan Gubeng",
                  "Taman Baca Hijau",
                  "20 Mei 2025",
                ],
                [
                  "PGJ-2025-0051",
                  "Karang Taruna Jagir",
                  "Lahan Wonokromo",
                  "Koridor Hijau",
                  "19 Mei 2025",
                ],
              ].map((row) => (
                <tr key={row[0]}>
                  {row.map((cell, index) => (
                    <td key={cell}>
                      {index === 0 ? <strong>{cell}</strong> : cell}
                    </td>
                  ))}
                  <td>
                    <Button
                      variant="secondary"
                      onClick={() => setAssignmentOpen(true)}
                    >
                      Buat Penugasan
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {tab === "active" && (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {[
                  "Pengajuan",
                  "Lahan",
                  "Petugas",
                  "Tanggal Tugas",
                  "Tenggat",
                  "Status",
                ].map((head) => (
                  <th key={head}>{head}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                [
                  "PGJ-2025-0049",
                  "Lahan Tambaksari",
                  "Budi Wibowo",
                  "20 Mei 2025",
                  "25 Mei 2025",
                  "Sedang Diverifikasi",
                ],
                [
                  "PGJ-2025-0047",
                  "Lahan Gayungan",
                  "Dimas Prasetyo",
                  "19 Mei 2025",
                  "24 Mei 2025",
                  "Ditugaskan",
                ],
                [
                  "PGJ-2025-0045",
                  "Lahan Lakarsantri",
                  "Nadia Putri",
                  "18 Mei 2025",
                  "23 Mei 2025",
                  "Sedang Diverifikasi",
                ],
              ].map((row) => (
                <tr key={row[0]}>
                  {row.map((cell, index) => (
                    <td key={cell}>
                      {index === 5 ? <StatusBadge status={cell} /> : cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {tab === "result" && (
        <div className="result-list">
          {[
            [
              "PGJ-2025-0039",
              "Kebun Komunitas Rungkut",
              "Budi Wibowo",
              "Sesuai",
              photos.rungkut,
            ],
            [
              "PGJ-2025-0036",
              "Taman Warga Gubeng",
              "Nadia Putri",
              "Belum Sesuai",
              photos.gubeng,
            ],
            [
              "PGJ-2025-0032",
              "Koridor Hijau Jagir",
              "Dimas Prasetyo",
              "Sesuai",
              photos.wonokromo,
            ],
          ].map(([id, title, officer, result, image]) => (
            <article className="panel result-row" key={id}>
              <img src={image} alt="" />
              <div>
                <span>{id}</span>
                <h2>{title}</h2>
                <p>Diperiksa oleh {officer} • 21 Mei 2025</p>
              </div>
              <Badge tone={result === "Sesuai" ? "green" : "yellow"}>
                {result}
              </Badge>
              <Button variant="secondary" onClick={() => setDetailOpen(true)}>
                Tinjau Hasil <ChevronRight size={15} />
              </Button>
            </article>
          ))}
        </div>
      )}

      {assignmentOpen && (
        <Modal
          title="Buat Penugasan"
          text="Penugasan akan dikirim ke petugas terpilih untuk memeriksa kondisi lahan secara langsung."
          onClose={() => setAssignmentOpen(false)}
        >
          <div className="assignment-summary">
            <div>
              <small>Pengajuan</small>
              <strong>PGJ-2025-0058 — Kebun Pangan Warga</strong>
            </div>
            <div>
              <small>Lahan</small>
              <strong>Lahan Kosong Rungkut • 1.250 m²</strong>
            </div>
          </div>
          <Field label="Pilih petugas">
            <select>
              <option>Budi Wibowo • 2 tugas aktif • Tersedia</option>
              <option>Nadia Putri • 1 tugas aktif • Tersedia</option>
              <option>Dimas Prasetyo • 5 tugas aktif • Tidak tersedia</option>
            </select>
          </Field>
          <div className="form-row">
            <Field label="Tanggal kunjungan">
              <input type="date" defaultValue="2025-05-23" />
            </Field>
            <Field label="Tenggat">
              <input type="date" defaultValue="2025-05-26" />
            </Field>
          </div>
          <Field label="Catatan instruksi untuk petugas">
            <textarea
              rows={4}
              placeholder="Periksa akses, sumber air, batas lahan, dan kondisi tanah..."
            />
          </Field>
          <div className="form-actions">
            <Button variant="ghost" onClick={() => setAssignmentOpen(false)}>
              Batal
            </Button>
            <Button
              onClick={() => {
                setAssignmentOpen(false)
                setTab("active")
                setToast("Penugasan berhasil dikirim ke Budi Wibowo")
              }}
            >
              Tugaskan <Send size={16} />
            </Button>
          </div>
        </Modal>
      )}

      {detailOpen && (
        <div className="detail-overlay">
          <button
            className="drawer-scrim"
            onClick={() => setDetailOpen(false)}
            aria-label="Tutup detail"
          />
          <aside className="verification-detail">
            <div className="drawer-head">
              <div>
                <span className="eyebrow">PGJ-2025-0039</span>
                <h2>Detail Hasil Verifikasi</h2>
              </div>
              <button onClick={() => setDetailOpen(false)}>
                <X size={19} />
              </button>
            </div>
            <section>
              <h3>Data Pengajuan & Lahan</h3>
              <div className="detail-kv">
                <span>
                  <small>Pemohon</small>
                  <strong>Siti Rahma — Komunitas Tumbuh</strong>
                </span>
                <span>
                  <small>Kegiatan</small>
                  <strong>Kebun Pangan Warga</strong>
                </span>
                <span>
                  <small>Lahan</small>
                  <strong>Lahan Kosong Rungkut • 1.250 m²</strong>
                </span>
              </div>
            </section>
            <section>
              <div className="result-title">
                <div>
                  <h3>Hasil Pemeriksaan Petugas</h3>
                  <p>Budi Wibowo • 21 Mei 2025, 14.35 WIB</p>
                </div>
                <Badge tone="green">Sesuai</Badge>
              </div>
              <p className="officer-note">
                Kondisi aktual sesuai data. Akses kendaraan tersedia, batas
                lahan jelas, dan sumber air dapat digunakan. Tidak ditemukan
                hambatan kepemilikan.
              </p>
              <div className="evidence-gallery">
                <img src={photos.rungkut} alt="Bukti kondisi lahan" />
                <img src={photos.gubeng} alt="Bukti akses lahan" />
                <img src={photos.wonokromo} alt="Bukti batas lahan" />
              </div>
            </section>
            <section className="decision-panel">
              <h3>Keputusan Admin</h3>
              <p>Pilih tindak lanjut berdasarkan hasil pemeriksaan petugas.</p>
              <div className="decision-grid">
                <Button onClick={() => setDecision("approve")}>
                  <CheckCircle2 size={17} /> Setujui Pengajuan
                </Button>
                <Button variant="danger" onClick={() => setDecision("reject")}>
                  <XCircle size={17} /> Tolak Pengajuan
                </Button>
                <button
                  className="decision-warning"
                  onClick={() => setDecision("revise")}
                >
                  <CircleAlert size={17} /> Minta Perbaikan ke Pemohon
                </button>
                <Button
                  variant="secondary"
                  onClick={() => setDecision("repeat")}
                >
                  <History size={17} /> Verifikasi Ulang
                </Button>
              </div>
            </section>
          </aside>
        </div>
      )}

      {decision && (
        <Modal
          title={
            decision === "approve"
              ? "Setujui Pengajuan?"
              : decision === "reject"
                ? "Tolak Pengajuan"
                : decision === "revise"
                  ? "Minta Perbaikan"
                  : "Tugaskan Verifikasi Ulang"
          }
          text="Status baru dan catatan keputusan akan otomatis tercatat di Riwayat Data."
          onClose={() => setDecision(null)}
        >
          {decision === "repeat" && (
            <Field label="Pilih petugas">
              <select>
                <option>Nadia Putri • Tersedia</option>
                <option>Budi Wibowo • 2 tugas aktif</option>
              </select>
            </Field>
          )}
          <Field
            label={
              decision === "approve"
                ? "Catatan keputusan (opsional)"
                : decision === "reject"
                  ? "Alasan penolakan *"
                  : "Catatan tindak lanjut *"
            }
          >
            <textarea
              rows={4}
              placeholder={
                decision === "approve"
                  ? "Tambahkan catatan bila diperlukan..."
                  : "Jelaskan alasan dan tindak lanjut yang diperlukan..."
              }
            />
          </Field>
          <div className="form-actions">
            <Button variant="ghost" onClick={() => setDecision(null)}>
              Batal
            </Button>
            <Button
              variant={decision === "reject" ? "danger" : "primary"}
              onClick={finishDecision}
            >
              Konfirmasi Keputusan
            </Button>
          </div>
        </Modal>
      )}
      {toast && (
        <div className="toast">
          <CheckCircle2 size={18} />
          <div>
            <strong>Berhasil</strong>
            <span>{toast}</span>
          </div>
        </div>
      )}
    </>
  )
}

function OfficerVerificationPage({ go }: { go: (page: Page) => void }) {
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">TUGAS VERIFIKASI</span>
          <h1>Tugas Lapangan Saya</h1>
          <p>Pilih tugas untuk mulai membuat laporan verifikasi lapangan.</p>
        </div>
      </div>
      <TaskTable go={() => go("laporan")} />
      <div className="task-connection">
        <span>
          <ClipboardCheck size={20} />
        </span>
        <div>
          <strong>Alur laporan terhubung</strong>
          <p>
            Saat membuka tugas, data pengajuan dan lahan otomatis terisi pada
            form Laporan Lapangan.
          </p>
        </div>
        <Button onClick={() => go("laporan")}>
          Buat Laporan Verifikasi <ChevronRight size={16} />
        </Button>
      </div>
    </>
  )
}

function VerificationPage({
  role,
  go,
}: {
  role: Role
  go: (page: Page) => void
}) {
  if (role === "admin") return <AdminVerificationPage />
  if (role === "petugas") return <OfficerVerificationPage go={go} />
  return <LegacyVerificationPage role={role} />
}

function MonitoringPage({ role }: { role: Role }) {
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">DAMPAK KEGIATAN</span>
          <h1>
            {role === "petugas"
              ? "Monitoring & Laporan"
              : "Monitoring Kegiatan"}
          </h1>
          <p>Pantau progres dan dokumentasi kegiatan yang sedang berjalan.</p>
        </div>
        {role === "petugas" && (
          <Button>
            <Plus size={18} /> Buat Laporan
          </Button>
        )}
      </div>
      <div className="monitor-grid">
        {[
          ["Kebun Pangan Rungkut", "78", "Baik"],
          ["Taman Baca Hijau Gubeng", "55", "Dalam Proses"],
          ["Koridor Hijau Jagir", "36", "Perlu Tinjauan"],
        ].map(([title, progress, status], i) => (
          <article className="panel monitor-card" key={title}>
            <img src={lands[i].image} alt="" />
            <div>
              <Badge tone={status === "Baik" ? "green" : "yellow"}>
                {status}
              </Badge>
              <h2>{title}</h2>
              <p>
                <MapPin size={14} /> {lands[i].address}
              </p>
              <div className="progress-head">
                <span>Progres kegiatan</span>
                <strong>{progress}%</strong>
              </div>
              <div className="progress">
                <span style={{ width: `${progress}%` }} />
              </div>
              <div className="monitor-foot">
                <span>
                  <Clock3 size={15} /> Laporan terakhir: 18 Mei 2025
                </span>
                <button>
                  Lihat Detail <ChevronRight size={15} />
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </>
  )
}

function TaskTable({ go }: { go?: (p: Page) => void }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {["Lahan", "Lokasi", "Pengaju", "Tenggat", "Status", "Aksi"].map(
              (h) => (
                <th key={h}>{h}</th>
              ),
            )}
          </tr>
        </thead>
        <tbody>
          {[
            [
              "Lahan Kosong Rungkut",
              "Rungkut",
              "Siti Rahma",
              "26 Mei 2025",
              "Tugas Baru",
            ],
            [
              "Lahan Tambaksari",
              "Tambaksari",
              "RW 04",
              "28 Mei 2025",
              "Dalam Proses",
            ],
            [
              "Lahan Gayungan",
              "Gayungan",
              "Karang Taruna",
              "30 Mei 2025",
              "Tugas Baru",
            ],
          ].map((r) => (
            <tr key={r[0]}>
              {r.map((c, i) => (
                <td key={c}>{i === 4 ? <StatusBadge status={c} /> : c}</td>
              ))}
              <td>
                <button
                  className="table-action"
                  onClick={() => go?.("verifikasi")}
                >
                  Periksa <ChevronRight size={14} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function ActivityList() {
  return (
    <div className="activity-list">
      {[
        [
          CheckCircle2,
          "Pengajuan disetujui",
          "Taman Baca Hijau Gubeng",
          "12 menit lalu",
        ],
        [
          FileText,
          "Pengajuan baru masuk",
          "Kebun Pangan Rungkut",
          "38 menit lalu",
        ],
        [
          Camera,
          "Laporan lapangan diunggah",
          "Koridor Hijau Jagir",
          "1 jam lalu",
        ],
        [Users, "Petugas baru ditambahkan", "Dimas Prasetyo", "3 jam lalu"],
      ].map(([Icon, title, text, time]) => {
        const I = Icon as typeof Leaf
        return (
          <div key={String(text)}>
            <span>
              <I size={17} />
            </span>
            <p>
              <strong>{String(title)}</strong>
              {String(text)}
            </p>
            <small>{String(time)}</small>
          </div>
        )
      })}
    </div>
  )
}

function HistoryPage() {
  const [selected, setSelected] = useState<string | null>(null)
  const logs = [
    [
      "21 Mei 2025, 16.42",
      "PGJ-2025-0058",
      "Verifikasi",
      "Diverifikasi",
      "Disetujui",
      "Arif Rahman",
      "Admin",
      "Hasil lapangan sesuai",
    ],
    [
      "21 Mei 2025, 14.35",
      "PGJ-2025-0058",
      "Verifikasi",
      "Ditugaskan",
      "Diverifikasi",
      "Budi Wibowo",
      "Petugas",
      "Pemeriksaan selesai",
    ],
    [
      "21 Mei 2025, 09.18",
      "PGJ-2025-0058",
      "Pengajuan",
      "Diajukan",
      "Ditugaskan",
      "Arif Rahman",
      "Admin",
      "Ditugaskan ke Budi",
    ],
    [
      "20 Mei 2025, 15.10",
      "PGJ-2025-0054",
      "Pengajuan",
      "Diajukan",
      "Perlu Perbaikan",
      "Arif Rahman",
      "Admin",
      "Jadwal belum lengkap",
    ],
    [
      "20 Mei 2025, 11.24",
      "PGJ-2025-0049",
      "Monitoring",
      "65%",
      "78%",
      "Nadia Putri",
      "Petugas",
      "Tanaman tumbuh baik",
    ],
    [
      "19 Mei 2025, 16.08",
      "PGJ-2025-0047",
      "Verifikasi",
      "Belum Ditugaskan",
      "Ditugaskan",
      "Sinta Dewi",
      "Admin",
      "Kunjungan 23 Mei",
    ],
    [
      "19 Mei 2025, 10.31",
      "LHN-SBY-041",
      "Lahan",
      "Draft",
      "Tersedia",
      "Arif Rahman",
      "Admin",
      "Data lahan dipublikasikan",
    ],
    [
      "18 Mei 2025, 13.15",
      "PGJ-2025-0045",
      "Pengajuan",
      "Diverifikasi",
      "Ditolak",
      "Sinta Dewi",
      "Admin",
      "Akses lahan bermasalah",
    ],
    [
      "17 Mei 2025, 09.44",
      "PGJ-2025-0041",
      "Pengajuan",
      "Perlu Perbaikan",
      "Diajukan Ulang",
      "Siti Rahma",
      "Masyarakat",
      "Dokumen diperbarui",
    ],
    [
      "16 Mei 2025, 17.02",
      "PGJ-2025-0039",
      "Monitoring",
      "45%",
      "60%",
      "Budi Wibowo",
      "Petugas",
      "Bedeng tanam selesai",
    ],
  ]
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">AUDIT AKTIVITAS</span>
          <h1>Riwayat Data</h1>
          <p>Telusuri setiap perubahan data dan status di dalam platform.</p>
        </div>
        <Button variant="secondary">
          <Download size={17} /> Ekspor
        </Button>
      </div>
      <div className="history-filters">
        <label>
          <Search size={16} />
          <input placeholder="Cari nomor, aktivitas, atau catatan..." />
        </label>
        <select>
          <option>Rentang: 30 hari terakhir</option>
        </select>
        <select>
          <option>Semua Aktivitas</option>
          <option>Pengajuan</option>
          <option>Verifikasi</option>
          <option>Monitoring</option>
          <option>Lahan</option>
        </select>
        <select>
          <option>Semua Pengguna</option>
          <option>Admin</option>
          <option>Petugas</option>
        </select>
      </div>
      <div className="table-wrap history-table">
        <table>
          <thead>
            <tr>
              {[
                "Waktu",
                "Nomor",
                "Aktivitas",
                "Perubahan Status",
                "Dilakukan Oleh",
                "Catatan",
              ].map((head) => (
                <th key={head}>{head}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {logs.map((row) => (
              <tr
                key={`${row[0]}-${row[1]}`}
                onClick={() => setSelected(row[1])}
              >
                <td>{row[0]}</td>
                <td>
                  <strong>{row[1]}</strong>
                </td>
                <td>{row[2]}</td>
                <td>
                  <div className="status-change">
                    <StatusBadge status={row[3]} />
                    <ChevronRight size={13} />
                    <StatusBadge status={row[4]} />
                  </div>
                </td>
                <td>
                  <div className="actor">
                    <span>
                      {row[5]
                        .split(" ")
                        .map((word) => word[0])
                        .join("")
                        .slice(0, 2)}
                    </span>
                    <div>
                      <strong>{row[5]}</strong>
                      <small>{row[6]}</small>
                    </div>
                  </div>
                </td>
                <td>{row[7]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="pagination">
        <span>Menampilkan 1–10 dari 84 aktivitas</span>
        <div>
          <button disabled>Sebelumnya</button>
          <button className="active">1</button>
          <button>2</button>
          <button>3</button>
          <button>Berikutnya</button>
        </div>
      </div>
      {selected && (
        <div className="detail-overlay">
          <button
            className="drawer-scrim"
            onClick={() => setSelected(null)}
            aria-label="Tutup panel"
          />
          <aside className="history-drawer">
            <div className="drawer-head">
              <div>
                <span className="eyebrow">{selected}</span>
                <h2>Detail Riwayat Pengajuan</h2>
              </div>
              <button onClick={() => setSelected(null)}>
                <X size={19} />
              </button>
            </div>
            <div className="drawer-summary">
              <small>Kegiatan</small>
              <strong>Kebun Pangan Warga Rungkut</strong>
              <small>Pemohon</small>
              <strong>Siti Rahma • Komunitas Tumbuh</strong>
              <small>Status saat ini</small>
              <StatusBadge status="Disetujui" />
            </div>
            <h3>Timeline Perubahan</h3>
            <div className="vertical-timeline">
              {[
                [
                  "Disetujui",
                  "Arif Rahman • Admin",
                  "21 Mei, 16.42",
                  "Hasil lapangan sesuai. Pengajuan dapat dilanjutkan.",
                ],
                [
                  "Diverifikasi",
                  "Budi Wibowo • Petugas",
                  "21 Mei, 14.35",
                  "Kondisi aktual sesuai data pengajuan.",
                ],
                [
                  "Ditugaskan",
                  "Arif Rahman • Admin",
                  "21 Mei, 09.18",
                  "Kunjungan lapangan dijadwalkan.",
                ],
                [
                  "Diajukan",
                  "Siti Rahma • Masyarakat",
                  "20 Mei, 10.12",
                  "Pengajuan berhasil dikirim.",
                ],
              ].map(([status, actor, time, note]) => (
                <div key={status}>
                  <i />
                  <section>
                    <StatusBadge status={status} />
                    <strong>{actor}</strong>
                    <small>{time}</small>
                    <p>{note}</p>
                  </section>
                </div>
              ))}
            </div>
          </aside>
        </div>
      )}
    </>
  )
}

function ReportPage() {
  const [view, setView] = useState<"list" | "form" | "detail">("list")
  const [sent, setSent] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [preview, setPreview] = useState(false)
  const [progress, setProgress] = useState(65)
  const reports = [
    ...(submitted
      ? [
          ["23 Mei 2025", "Lahan Kosong Rungkut", "Verifikasi", "Terkirim"],
        ] as string[][]
      : []),
    ["21 Mei 2025", "Lahan Kosong Rungkut", "Verifikasi", "Terkirim"],
    ["18 Mei 2025", "Koridor Hijau Jagir", "Monitoring", "Terkirim"],
    ["14 Mei 2025", "Taman Gubeng", "Monitoring", "Draft"],
    ["10 Mei 2025", "Lahan Tambaksari", "Verifikasi", "Ditinjau Admin"],
  ]
  if (view === "detail")
    return (
      <>
        <button className="back-link" onClick={() => setView("list")}>
          <ChevronRight size={17} /> Kembali ke Daftar Laporan
        </button>
        <div className="page-intro">
          <div>
            <span className="eyebrow">LAP-2025-0048</span>
            <h1>Detail Laporan Verifikasi</h1>
            <p>Dikirim 21 Mei 2025, 14.35 WIB</p>
          </div>
          <Badge tone="green">Terkirim</Badge>
        </div>
        <div className="report-detail-grid">
          <section className="panel detail-panel">
            <h2>Informasi Laporan</h2>
            <div className="info-grid">
              <div>
                <span>Jenis</span>
                <strong>Verifikasi</strong>
              </div>
              <div>
                <span>Lahan</span>
                <strong>Lahan Rungkut</strong>
              </div>
              <div>
                <span>Hasil</span>
                <strong>Sesuai</strong>
              </div>
              <div>
                <span>Progres</span>
                <strong>100%</strong>
              </div>
            </div>
            <h3>Catatan Petugas</h3>
            <p>
              Kondisi lahan sesuai data, akses kendaraan tersedia, batas lahan
              terlihat jelas, dan sumber air dapat digunakan untuk kegiatan
              urban farming.
            </p>
            <h3>Dokumentasi Lapangan</h3>
            <div className="report-gallery">
              <img src={photos.rungkut} alt="Kondisi lahan" />
              <img src={photos.gubeng} alt="Akses lahan" />
              <img src={photos.wonokromo} alt="Batas lahan" />
            </div>
          </section>
          <aside className="panel task-summary">
            <h2>Petugas Pelapor</h2>
            <div className="profile-summary">
              <span>BW</span>
              <div>
                <strong>Budi Wibowo</strong>
                <small>NIP 19880412 201001 1 009</small>
              </div>
            </div>
            <div className="info-list">
              <span>
                <small>Unit kerja</small>
                <strong>UPT Surabaya Timur</strong>
              </span>
              <span>
                <small>Tugas</small>
                <strong>VRF-2025-028</strong>
              </span>
              <span>
                <small>Lokasi GPS</small>
                <strong>Terverifikasi</strong>
              </span>
            </div>
          </aside>
        </div>
      </>
    )
  if (view === "form")
    return (
      <>
        <button className="back-link" onClick={() => setView("list")}>
          <ChevronRight size={17} /> Kembali ke Daftar Laporan
        </button>
        <div className="page-intro">
          <div>
            <span className="eyebrow">LAPORAN BARU</span>
            <h1>Buat Laporan Lapangan</h1>
            <p>Data tugas aktif akan terhubung otomatis ke laporan ini.</p>
          </div>
        </div>
        <div className="form-layout">
          <section className="panel form-card">
            <div className="form-row">
              <Field label="Jenis laporan *">
                <select>
                  <option>Verifikasi Lapangan</option>
                  <option>Monitoring Kegiatan</option>
                </select>
              </Field>
              <Field label="Tugas / Pengajuan *">
                <select>
                  <option>VRF-2025-028 • PGJ-2025-0058 • Rungkut</option>
                  <option>MON-2025-014 • Koridor Hijau Jagir</option>
                </select>
              </Field>
            </div>
            <div className="form-row">
              <Field label="Tanggal laporan *">
                <input type="date" defaultValue="2025-05-23" />
              </Field>
              <Field label="Kondisi lahan / kegiatan *">
                <select>
                  <option>Baik dan sesuai</option>
                  <option>Perlu tindak lanjut</option>
                  <option>Tidak dapat diperiksa</option>
                </select>
              </Field>
            </div>
            <Field label={`Progres kegiatan — ${progress}%`}>
              <input
                className="progress-slider"
                type="range"
                min="0"
                max="100"
                value={progress}
                onChange={(event) => setProgress(Number(event.target.value))}
              />
            </Field>
            <div className="form-row">
              <Field label="Hasil pemeriksaan *">
                <select>
                  <option>Sesuai</option>
                  <option>Belum Sesuai</option>
                </select>
              </Field>
              <Field label="Kendala (opsional)">
                <select>
                  <option>Tidak ada kendala</option>
                  <option>Lokasi tidak dapat diakses</option>
                  <option>Cuaca tidak mendukung</option>
                  <option>Pengelola tidak berada di lokasi</option>
                </select>
              </Field>
            </div>
            <Field label="Catatan lapangan *">
              <textarea
                rows={5}
                placeholder="Jelaskan kondisi, temuan, dan rekomendasi tindak lanjut..."
              />
            </Field>
            <Field label="Foto dokumentasi *">
              <div className="upload-zone report-upload">
                <Camera size={28} />
                <strong>Unggah beberapa foto</strong>
                <span>
                  JPG atau PNG • Maksimal 5 MB/file • Maksimal 10 foto
                </span>
                <Button variant="secondary" onClick={() => setPreview(true)}>
                  Pilih Foto
                </Button>
              </div>
            </Field>
            {preview && (
              <div className="upload-previews">
                {[photos.rungkut, photos.gubeng, photos.wonokromo].map(
                  (image, index) => (
                    <div key={image}>
                      <img src={image} alt={`Preview foto ${index + 1}`} />
                      <button>
                        <X size={13} />
                      </button>
                      <span>
                        {index === 0
                          ? "lahan-depan.jpg"
                          : `bukti-${index + 1}.jpg`}
                        <small>{1.2 + index / 2} MB</small>
                      </span>
                    </div>
                  ),
                )}
              </div>
            )}
            <div className="upload-validation">
              <CheckCircle2 size={15} /> Semua file memenuhi format dan ukuran
              yang diizinkan.
            </div>
            <div className="form-actions">
              <Button variant="ghost" onClick={() => setView("list")}>
                Simpan Draft
              </Button>
              <Button onClick={() => setSent(true)}>
                Kirim Laporan <Send size={16} />
              </Button>
            </div>
          </section>
          <aside className="panel task-summary">
            <h2>Ringkasan Tugas</h2>
            <img src={photos.rungkut} alt="" />
            <h3>Lahan Kosong Rungkut</h3>
            <p>
              <MapPin size={15} /> Rungkut, Surabaya
            </p>
            <div className="info-list">
              <span>
                <small>Pengajuan</small>
                <strong>PGJ-2025-0058</strong>
              </span>
              <span>
                <small>Tenggat</small>
                <strong>26 Mei 2025</strong>
              </span>
              <span>
                <small>Status</small>
                <strong>Dalam Proses</strong>
              </span>
            </div>
          </aside>
        </div>
        {sent && (
          <Modal
            title="Laporan berhasil dikirim"
            text="Laporan LAP-2025-0052 telah diteruskan kepada admin dan muncul di daftar laporan."
            onClose={() => {
              setSent(false)
              setSubmitted(true)
              setView("list")
            }}
          >
            <div className="modal-success">
              <span>
                <Check size={30} />
              </span>
              <strong>LAP-2025-0052</strong>
              <p>
                Status tugas otomatis berubah menjadi “Menunggu Keputusan
                Admin”.
              </p>
              <Button
                onClick={() => {
                  setSent(false)
                  setSubmitted(true)
                  setView("list")
                }}
              >
                Kembali ke Daftar Laporan
              </Button>
            </div>
          </Modal>
        )}
      </>
    )
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">DOKUMENTASI LAPANGAN</span>
          <h1>Laporan Lapangan</h1>
          <p>Kelola laporan verifikasi dan monitoring yang telah Anda kirim.</p>
        </div>
        <Button onClick={() => setView("form")}>
          <Plus size={18} /> Buat Laporan Baru
        </Button>
      </div>
      <div className="stats-grid four">
        <StatCard
          label="Total Laporan"
          value="18"
          note="Bulan ini"
          icon={FileText}
        />
        <StatCard
          label="Verifikasi"
          value="07"
          note="3 ditinjau admin"
          icon={ClipboardCheck}
          tone="blue"
        />
        <StatCard
          label="Monitoring"
          value="09"
          note="Kegiatan aktif"
          icon={Activity}
        />
        <StatCard
          label="Draft"
          value="02"
          note="Belum dikirim"
          icon={Clock3}
          tone="yellow"
        />
      </div>
      <div className="filter-bar">
        <label>
          <Search size={17} />
          <input placeholder="Cari lahan atau nomor laporan..." />
        </label>
        <Button variant="secondary">
          <Filter size={16} /> Semua Jenis
        </Button>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              {["Tanggal", "Lahan", "Jenis", "Status", "Aksi"].map((head) => (
                <th key={head}>{head}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {reports.map((row) => (
              <tr key={`${row[0]}-${row[1]}`}>
                {row.map((cell, index) => (
                  <td key={cell}>
                    {index === 2 ? (
                      <Badge tone="light">{cell}</Badge>
                    ) : index === 3 ? (
                      <StatusBadge status={cell} />
                    ) : (
                      cell
                    )}
                  </td>
                ))}
                <td>
                  <button
                    className="table-action"
                    onClick={() => setView("detail")}
                  >
                    <Eye size={15} /> Lihat Detail
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function ProfilePage({ role }: { role: Role }) {
  const [editing, setEditing] = useState(false)
  const [saved, setSaved] = useState(false)
  const isAdmin = role === "admin"
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">AKUN SAYA</span>
          <h1>Profil & Biodata</h1>
          <p>
            Kelola identitas dan informasi kerja yang digunakan pada platform.
          </p>
        </div>
        {!editing && (
          <Button variant="secondary" onClick={() => setEditing(true)}>
            <Pencil size={16} /> Edit Profil
          </Button>
        )}
      </div>
      <div className="profile-layout">
        <aside className="panel profile-card">
          <Logo variant="profile" />
          <span>{isAdmin ? "AR" : "BW"}</span>
          <h2>{isAdmin ? "Arif Rahman" : "Budi Wibowo"}</h2>
          <p>{isAdmin ? "Administrator Sistem" : "Petugas Lapangan"}</p>
          <Badge tone="green">Akun Aktif</Badge>
          <div>
            <small>Terakhir masuk</small>
            <strong>21 Mei 2025, 08.14 WIB</strong>
          </div>
        </aside>
        <section className="panel profile-form">
          <div className="profile-section-head">
            <div>
              <UserRound size={19} />
              <span>
                <strong>Informasi Pribadi</strong>
                <small>Data identitas utama akun</small>
              </span>
            </div>
          </div>
          <div className="form-row">
            <Field label="Nama lengkap">
              <input
                disabled={!editing}
                defaultValue={isAdmin ? "Arif Rahman" : "Budi Wibowo"}
              />
            </Field>
            <Field label="NIK">
              <input
                disabled={!editing}
                defaultValue={isAdmin ? "3578011203850004" : "3578021204880009"}
              />
            </Field>
          </div>
          <div className="form-row">
            <Field label="Email">
              <input
                disabled={!editing}
                defaultValue={
                  isAdmin
                    ? "arif.rahman@surabaya.go.id"
                    : "budi.wibowo@surabaya.go.id"
                }
              />
            </Field>
            <Field label="Nomor HP">
              <input
                disabled={!editing}
                defaultValue={isAdmin ? "0812 3456 781" : "0819 2278 511"}
              />
            </Field>
          </div>
          <Field label="Alamat">
            <textarea
              disabled={!editing}
              rows={3}
              defaultValue="Jl. Jimerto No. 25–27, Surabaya"
            />
          </Field>
          <div className="profile-section-head">
            <div>
              <BriefcaseBusiness size={19} />
              <span>
                <strong>Informasi Pekerjaan</strong>
                <small>Jabatan dan unit kerja</small>
              </span>
            </div>
          </div>
          <div className="form-row">
            <Field label="Jabatan">
              <input
                disabled={!editing}
                defaultValue={
                  isAdmin ? "Analis Pengelolaan Aset" : "Pengawas Lapangan"
                }
              />
            </Field>
            <Field label="Unit kerja">
              <input
                disabled={!editing}
                defaultValue={
                  isAdmin ? "Bidang Pemanfaatan Aset" : "UPT Surabaya Timur"
                }
              />
            </Field>
          </div>
          <div className="form-row">
            <Field label="NIP / Nomor pegawai">
              <input
                disabled={!editing}
                defaultValue={
                  isAdmin ? "19850312 201001 1 004" : "19880412 201001 1 009"
                }
              />
            </Field>
            <Field label="Wilayah tugas">
              <input
                disabled={!editing}
                defaultValue={isAdmin ? "Kota Surabaya" : "Surabaya Timur"}
              />
            </Field>
          </div>
          {saved && (
            <div className="form-success">
              <CheckCircle2 size={17} /> Profil berhasil diperbarui.
            </div>
          )}
          {editing && (
            <div className="form-actions">
              <Button variant="ghost" onClick={() => setEditing(false)}>
                Batal
              </Button>
              <Button
                onClick={() => {
                  setEditing(false)
                  setSaved(true)
                }}
              >
                Simpan Perubahan
              </Button>
            </div>
          )}
        </section>
      </div>
    </>
  )
}

function GenericPage({ page, role }: { page: Page role: Role }) {
  const config: Partial<Record<Page, [string, string]>> = {
    rekomendasi: [
      "Rekomendasi Pemanfaatan",
      "Alternatif kegiatan sesuai karakteristik dan potensi lahan.",
    ],
    riwayat: [
      "Riwayat Pengajuan",
      "Lihat seluruh perubahan status dan catatan pengajuan.",
    ],
    perkembangan: [
      "Perkembangan Kegiatan",
      "Pantau laporan dan dokumentasi kegiatan yang disetujui.",
    ],
    pengguna: [
      "Pengelolaan Pengguna",
      "Kelola akun admin, masyarakat, komunitas, dan petugas lapangan.",
    ],
    "riwayat-data": [
      "Riwayat Data",
      "Audit log perubahan status dan aktivitas pengguna.",
    ],
    laporan: [
      "Laporan Lapangan",
      "Kirim dan tinjau riwayat dokumentasi dari lapangan.",
    ],
  }
  const [title, text] = config[page] || ["Halaman", "Informasi PERLAHAN"]
  if (page === "rekomendasi")
    return (
      <>
        <div className="page-intro">
          <div>
            <span className="eyebrow">INFORMASI AWAL</span>
            <h1>{title}</h1>
            <p>{text}</p>
          </div>
        </div>
        <Recommendations />
      </>
    )
  if (page === "perkembangan") return <MonitoringPage role={role} />
  if (page === "pengguna")
    return (
      <>
        <div className="page-intro">
          <div>
            <span className="eyebrow">AKSES PLATFORM</span>
            <h1>{title}</h1>
            <p>{text}</p>
          </div>
          <Button>
            <Plus size={18} /> Tambah Petugas
          </Button>
        </div>
        <div className="filter-bar">
          <label>
            <Search size={18} />
            <input placeholder="Cari nama atau email..." />
          </label>
          <Button variant="secondary">
            <Filter size={17} /> Semua Role
          </Button>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {["Nama", "Email", "No. HP", "Role", "Status", "Aksi"].map(
                  (h) => (
                    <th key={h}>{h}</th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {[
                ["Arif Rahman", "arif@perlahan.id", "0812 3456 781", "Admin"],
                ["Siti Rahma", "siti@email.com", "0813 7721 004", "Masyarakat"],
                ["Budi Wibowo", "budi@perlahan.id", "0819 2278 511", "Petugas"],
              ].map((r) => (
                <tr key={r[0]}>
                  {r.map((c) => (
                    <td key={c}>{c}</td>
                  ))}
                  <td>
                    <Badge tone="green">Aktif</Badge>
                  </td>
                  <td>
                    <button className="table-action">
                      <Pencil size={15} /> Kelola
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    )
  return (
    <>
      <div className="page-intro">
        <div>
          <span className="eyebrow">ARSIP SISTEM</span>
          <h1>{title}</h1>
          <p>{text}</p>
        </div>
      </div>
      <div className="filter-bar">
        <label>
          <Search size={18} />
          <input placeholder="Cari data..." />
        </label>
        <Button variant="secondary">
          <Filter size={17} /> Filter Tanggal
        </Button>
      </div>
      <SubmissionTable
        role={role === "admin" ? "admin" : "masyarakat"}
        go={() => {}}
      />
    </>
  )
}

export default function App() {
  const [page, setPage] = useState<Page>("landing")
  const [role, setRole] = useState<Role>("masyarakat")
  const publicPage =
    page === "landing" || page === "login" || page === "register"
  const content = useMemo(() => {
    if (page === "dashboard") return <Dashboard role={role} go={setPage} />
    if (page === "lahan") return <LandsPage role={role} go={setPage} />
    if (page === "peta") return <MapPage go={setPage} />
    if (page === "detail") return <DetailPage go={setPage} />
    if (page === "pengajuan") return <ApplicationForm go={setPage} />
    if (page === "status") return <StatusPage role={role} go={setPage} />
    if (page === "verifikasi")
      return <VerificationPage role={role} go={setPage} />
    if (page === "monitoring") return <MonitoringPage role={role} />
    if (page === "riwayat-data") return <HistoryPage />
    if (page === "laporan") return <ReportPage />
    if (page === "profil") return <ProfilePage role={role} />
    return <GenericPage page={page} role={role} />
  }, [page, role])

  if (page === "landing") return <Landing go={setPage} />
  if (page === "login" || page === "register")
    return (
      <Auth
        page={page}
        go={setPage}
        onLogin={(selectedRole) => {
          setRole(selectedRole)
          setPage("dashboard")
        }}
      />
    )
  return (
    <AppShell
      role={role}
      page={page}
      go={(target) => {
        if (target === "landing") {
          setPage("landing")
        } else {
          setPage(target)
        }
      }}
    >
      {publicPage ? null : content}
    </AppShell>
  )
}
